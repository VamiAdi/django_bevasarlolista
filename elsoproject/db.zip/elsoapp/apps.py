from django.apps import AppConfig


class ElsoappConfig(AppConfig):
    name = 'elsoapp'
